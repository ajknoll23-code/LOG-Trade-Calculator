# KTC V2 — V34 separate Apps Script deployment preparation (NO VOTES)

**Nothing here is deployed or activated.** This archive is generated from GitHub's verified V31 and V33 files. It does NOT contain live tokens, endpoints, spreadsheet IDs or credentials. It is not a participant recruitment kit.

## Operator preparation, not launch

1. Using a dedicated Google account/project and authorized access, create a **new** Google Sheet named `KTC V2 Isolated Research — DISABLED`. Restrict its sharing. In a `Responses` tab, paste the header row from `RESPONSES_HEADERS.txt` into 13 separate cells of row 1; confirm the order exactly. No participant or personal data may be added.
2. Create a **new separate** Apps Script project, not attached to the existing V1 collector. Add `Code.gs` (contains V31 collector and V33 HTML host) and an HTML file named exactly `pilot-frame`, populated with `pilot-frame.html`.
3. Set the nine nonsecret flags from `SCRIPT_PROPERTIES_DISABLED_EXAMPLE.json` as string values using the Apps Script UI. The flags MUST remain false; use no real player keys, participant tokens, URLs, or secret values in this step.
4. Leave the web application **unpublished** until a reviewed dummy-only deployment procedure exists. If an inactive deployment is reviewed later, prove its public `/exec` returns the disabled status and no real ballot. Do not bypass gates by setting approval flags true.
5. Before any later dummy end-to-end or human test, review HtmlService cross-origin framing and `XFrameOptionsMode.ALLOWALL` clickjacking exposure; `document.referrer` may be empty or from a Google wrapper. Do not weaken a failed origin check without independent security approval. Google Apps Script time-based deletion triggers, V1/V2 sheet isolation, and 30-day deletion of all exports/backup copies are not configured or verified by this pack.
6. At the next gate, a dedicated dummy-only staging mode or test-only project is needed for RPC acceptance testing **without falsely declaring owner authorization or independent human QC**. No live respondent contact until a separate explicit owner authorization after completed wording/privacy/security reviews.

## Why this is not a working system yet

A disabled code package is not a usable server. An Apps Script project and a new independent Sheet have to exist; restricted sharing, Script Properties, secret generation, deletion trigger, embedded-iframe behavior, RPC result acknowledgments, moderator SOP and human review require live-account verification. The V2 page within Market Research continues to show fictional practice examples only. V1 Market Value aggregation, FV, and Package Adjustment are untouched.

Study scope: the proposed first cohort of 12 is for **comprehension/usability**, not statistically valid market valuation. Seven identity holds and nine optional shadow ballots remain held.
